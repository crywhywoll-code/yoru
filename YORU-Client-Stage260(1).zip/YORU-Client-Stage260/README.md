# YORU Client — Android bootstrap

Minimal Android Studio project for the YORU Client UI foundation.

## Build locally

Requirements: JDK 17, Gradle 8.9, Android SDK Platform 35, Build Tools 35.0.0.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build on GitHub

Push the project contents to the `main` branch or run **Actions → Android Debug Build** manually. The workflow provisions JDK, Android SDK and Gradle, builds the debug APK, and uploads it as `yoru-client-debug` artifact.

This is a bootstrap UI only. It does not yet integrate with Minecraft or implement the planned client modules.
