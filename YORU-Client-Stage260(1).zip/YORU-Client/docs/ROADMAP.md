# Roadmap

1. Buildable Android shell and CI.
2. Complete UI components and settings persistence.
3. Import library: file picker, MIME tests, archive validation, safe extraction, metadata and duplicate handling.
4. Bedrock compatibility research for target Android versions.
5. Verified world/resource-pack integration.
6. Runtime HUD and square minimap data pipeline.
7. Combat/render modules subject to game API and multiplayer compatibility.
8. Device testing on Android and release signing.

No feature should be labeled implemented until tested on the target Minecraft Bedrock build.
