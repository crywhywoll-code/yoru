# Halcyon 25.3.1 / Minecraft PE 1.1.5.1 — APK research

## Scope and method

This is a static inspection of the two APK files supplied for this project. It inspected APK ZIP contents, native-library metadata, SHA-256 hashes, ELF dynamic symbols and visible DEX strings. It did not execute either APK, attach a debugger, inspect live process memory, or validate runtime calls.

The supplied APKs are not included in this project archive. This avoids redistributing third-party application binaries.

## Confirmed package observations

### Halcyon APK (`хвх.apk`)

- APK size: 16,166,392 bytes (about 15.4 MiB).
- Contains one `classes.dex` (2,860,032 bytes).
- Contains ARMv7 native libraries:
  - `lib/armeabi-v7a/liblauncher.so` (396,172 bytes)
  - `lib/armeabi-v7a/libminecraftpe.so` (37,980,728 bytes)
  - `lib/armeabi-v7a/libsubstrate.so` (17,528 bytes)
  - `lib/armeabi-v7a/libfmod.so` (1,186,316 bytes)
- The launcher ELF is 32-bit ARM, EABI5, and stripped.
- DEX strings identify the application as Halcyon 25.3.1 and expose Java-side names including `HalcyonActivity`, `MainActivity`, `MinecraftActivity`, `module.Api`, and `sdk.LibraryLoader`.

### Minecraft APK (`base.apk`)

- APK size: 58,756,420 bytes (about 56.0 MiB).
- Contains one `classes.dex` (8,240 bytes).
- Contains `lib/armeabi-v7a/libminecraftpe.so` (37,980,728 bytes) and `libfmod.so`.
- Its DEX strings and package metadata identify Minecraft PE 1.1.5.1 and package `com.mojang.minecraftpe`.
- The APK includes the game's vanilla behavior/resource assets.

## Important compatibility result

The two `libminecraftpe.so` files have the same file size, but **different SHA-256 hashes**:

- Halcyon APK copy: `44271c905daf0a79269fc5b230bee245469f0e1e2f3f2189bc98c4d52bbc7359`
- Supplied Minecraft APK copy: `3eed76a1659e562bf7a1e5efc6119f179c312d3a46b8ce68454b486ba5ed7ddf`

Therefore, equal size and ARMv7 ABI do not establish binary identity. Halcyon's embedded game library may be patched or otherwise different. Function offsets, signatures, and assumptions must not be copied across the two binaries without verification.

## Halcyon native interface evidence

The dynamic symbol table of `liblauncher.so` exposes a family of `Api_*` symbols. The names indicate functional groups including:

- game state and FPS queries;
- player/entity state and position queries;
- yaw/pitch and movement-related accessors;
- inventory, item, and equipment queries;
- block and screen queries;
- text drawing and world-to-screen helpers;
- lifecycle symbols such as `Halcyon::setupNatives` and `Halcyon::initModules`.

The library also imports/uses Minecraft C++ symbols associated with `MinecraftGame`, `ClientInstance`, player loading, and graphics updates.

**Caution:** symbol names are evidence of an interface surface, not a complete API contract. Exact signatures, ownership, thread requirements, object lifetimes, call order, and runtime compatibility remain unverified. The project must not call these functions merely because their names are visible.

## YORU architecture decision

Use Halcyon's overall separation of concerns as a research reference:

1. Android application and user interface.
2. Native boundary (JNI).
3. Version-specific Minecraft adapter.
4. Stable YORU game-facing interfaces.
5. Event dispatcher and module lifecycle.
6. Render/HUD integration as a separate capability.

YORU should own its interfaces and implementation. This archive does not copy Halcyon's native library, Substrate, Java classes, offsets, or proprietary source code.

## Next validation work

- Obtain lawful source-level documentation or a user-provided source archive if available.
- Compare the two game libraries at the ELF/build-id/section and symbol level.
- Establish the exact runtime package, ABI, Android API range, and launch/data-directory behavior.
- Validate one harmless read-only capability at a time in a controlled test build.
- Keep unsupported capabilities disabled and report them as unavailable rather than presenting mock data as live game state.

## Current status

The current YORU ZIP contains architecture scaffolding and a static research report. It does **not** yet inject into, launch, patch, or control Minecraft. JNI is not wired into the Android build, and no game-facing function has been runtime-validated.
