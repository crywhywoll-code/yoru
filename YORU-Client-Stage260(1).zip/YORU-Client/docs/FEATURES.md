# YORU Client — Feature Catalog

## Global UI
- Logo: 个
- AMOLED: pure black #000000
- Glass: dark graphite surfaces
- Accent: white #FFFFFF
- Landscape menu shown during gameplay (target behavior; runtime integration pending)
- Dynamic Island: one tap expands compact panel; double tap opens full menu; drag to reposition; persist position.
- Startup: splash → launch Minecraft → greeting island “С возвращением, {Minecraft player name}” → collapse to compact state. Player name comes from Minecraft profile if accessible; fallback without name.

## Combat
- Attack: TriggerBot, AutoClicker (specification only; server rules and fair-play constraints apply)
- Aim: AimBot, Target Assist (target point Head/Body, aim duration, controlled assist)
- Visuals: Target HUD, Hitbox, Target ESP, Reach Display, Combat Stats
- Target HUD appears when damaged by a player or when hitting a player; shows name, health, distance and damage state. Updates without flicker.
- Any combat automation requires separate technical, policy, and multiplayer-server compatibility review.

## Render / Visuals
- Chams: player highlighting with visible/occluded colors, fill/outline and opacity (runtime support to verify).
- MiniMap is SQUARE, resizable and repositionable.
- Player dots with configurable colors and sizes; friend/enemy colors; optional names, distance and health.
- Biome overlay; compass; coordinates; rotation mode (player-up / north-up); zoom.
- Double tap on MiniMap opens player list with name, health, distance, privilege and coordinates. Privilege is read only from an authoritative in-game player list if exposed; otherwise “Unknown”.
- Waypoints, route-to-waypoint, death point, cave map only for explored/available data, entity radar.
- MiniMap must not invent terrain, biome or player data.

## Storage / Imports
- Store worlds and packs internally under `filesDir/minecraft/`.
- `worlds/`, `resource_packs/`, `behavior_packs/`, `skin_packs/`, `imports/`.
- Never export imported pack/world media into public Gallery or DCIM.
- Receive `.mcworld`, `.mcpack`, `.mcaddon` using Android `ACTION_VIEW` / `ACTION_SEND` content URIs.
- Copy from `ContentResolver` into app-private storage; validate extension, size, archive structure, manifest and UUIDs before installation.
- Keep worlds/packs in separate folders, maintain metadata/index, prevent duplicate UUIDs, support rename/delete/export.
- Import chooser: Android only shows YORU if the sender supplies a matching MIME type and installed app declares a matching intent filter. Some file managers use `application/octet-stream`; register common MIME types and provide an in-app “Open with YORU” file picker as fallback. Do not claim universal chooser compatibility.
- For true Minecraft interoperability, validate `.mcworld` / `.mcpack` / `.mcaddon` format and implement import semantics compatible with the installed Bedrock version. Current prototype only copies incoming streams into `imports/`; it does not install packs into Minecraft.

## Technical status
- Implemented: Android Compose prototype, category navigation, square minimap placeholder, basic import stream reception/copy to app-private imports folder, manifest intent filters.
- Planned/prototype: full feature settings, splash flow, dynamic island animations, persistent HUD editor, library manager.
- Requires Bedrock runtime/API research: in-game rendering, player/entity data, biomes, privileges, world list integration, pack activation and import interoperability.
