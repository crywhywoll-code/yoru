# Internal worlds and resource-pack storage

## Desired user experience
1. User downloads a `.mcpack`, `.mcaddon`, or `.mcworld`.
2. Android share/open chooser offers Minecraft and YORU Client when MIME metadata matches declared intent filters.
3. User chooses YORU.
4. YORU copies the content URI into private app storage.
5. Import manager validates archive and manifest, extracts to the appropriate private folder, and registers it in the library.
6. User can browse, rename, activate/deactivate (when Bedrock integration supports it), export, or delete from YORU without cluttering Gallery.

## Important Android limitation
An app cannot force itself to appear in every “Open with” chooser. The sending app controls the URI and MIME type; Android resolves compatible intent filters. Some file managers send unknown types as `application/octet-stream`. Include a fallback in-app import action using `ACTION_OPEN_DOCUMENT` with `*/*` and extension validation.

## Prototype implementation
MainActivity currently receives VIEW/SEND intents and copies the input stream into:
`filesDir/minecraft/imports/`

This is deliberately only an intake prototype. It does not unpack or activate packs and does not modify Minecraft's own world/pack directories. A real installer must validate `.mcworld` / `.mcpack` / `.mcaddon`, safely inspect ZIP entries against path traversal, check manifests and UUIDs, and then use a verified Bedrock integration path.
