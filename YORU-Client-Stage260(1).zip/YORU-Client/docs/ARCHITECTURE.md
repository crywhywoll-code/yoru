# Architecture

Planned modules:
- core: lifecycle, capability detection, feature flags
- api: Bedrock adapter boundary (not implemented)
- modules: combat/movement/render/build/world features
- managers: module, event, command, config, notification
- input: touch and gesture routing
- render: HUD, minimap, chams and visual overlays
- island: Dynamic Island state machine and animation
- storage: app-private worlds/packs/import manager
- diagnostics: logs and runtime compatibility

Storage boundary:
`context.filesDir/minecraft/{worlds,resource_packs,behavior_packs,skin_packs,imports}`

Do not use public Pictures/DCIM or MediaStore for world/pack archives. Use ContentResolver for incoming content URIs and SAF for explicit exports.
