package com.yoru.client.bridge

/**
 * Android-side status contract for the future JNI bridge.
 *
 * This is UI-facing scaffolding only. No native library is loaded yet and
 * values must not be presented as live Minecraft data.
 */
enum class GameRuntimeState {
    UNAVAILABLE,
    LOADING,
    IN_GAME,
    LEAVING
}

data class GameBridgeStatus(
    val state: GameRuntimeState = GameRuntimeState.UNAVAILABLE,
    val detail: String = "Native Minecraft bridge is not connected"
)
