package com.yoru.client

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.File

private val Black = Color(0xFF000000)
private val Panel = Color(0xF0181818)
private val Panel2 = Color(0xF0212121)
private val Card = Color(0xFF292929)
private val White = Color(0xFFFFFFFF)
private val Muted = Color(0xFFAAAAAA)
private val Soft = Color(0xFF777777)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleImportIntent(intent)
        setContent { YoruApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleImportIntent(intent)
    }

    private fun handleImportIntent(intent: Intent?) {
        if (intent == null) return
        val uri = intent.data ?: intent.getParcelableExtra(Intent.EXTRA_STREAM) as? android.net.Uri
        if (uri != null) runCatching {
            val base = File(filesDir, "minecraft/imports").apply { mkdirs() }
            val name = (contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
            } ?: "incoming-pack-${System.currentTimeMillis()}.zip")
                .replace(Regex("[^A-Za-z0-9._-]"), "_")
            contentResolver.openInputStream(uri)?.use { input ->
                File(base, name).outputStream().use(input::copyTo)
            }
        }
    }
}

@Composable
private fun YoruApp() {
    var selected by remember { mutableStateOf("Combat") }
    var islandExpanded by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var showPlayerList by remember { mutableStateOf(false) }
    val categories = listOf("Info", "Combat", "Movement", "Render", "Player", "World", "Utility", "Visual", "Misc", "Settings")
    MaterialTheme(colorScheme = darkColorScheme(primary = White, background = Black, surface = Panel2)) {
        Box(Modifier.fillMaxSize().background(Black)) {
            // Lightweight in-game HUD preview. It is not connected to live game data yet.
            Column(Modifier.align(Alignment.TopEnd).padding(16.dp).background(Panel, RoundedCornerShape(15.dp)).border(1.dp, Color(0xFF414141), RoundedCornerShape(15.dp)).padding(horizontal = 15.dp, vertical = 11.dp)) {
                Text("FPS: --", color = White, fontSize = 13.sp)
                Text("Ping: -- ms", color = Muted, fontSize = 13.sp)
                Text("TPS: --", color = Muted, fontSize = 13.sp)
            }
            Column(Modifier.align(Alignment.BottomEnd).padding(16.dp).background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
                Text("Keybinds", color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text("R — Open GUI", color = Muted, fontSize = 11.sp)
                Text("Right Shift — Hide GUI", color = Muted, fontSize = 11.sp)
            }
            // Dynamic Island remains independent from the main menu.
            Island(
                expanded = islandExpanded,
                onTap = { islandExpanded = !islandExpanded },
                onDoubleTap = { menuOpen = true; islandExpanded = false }
            , modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp))

            AnimatedVisibility(
                visible = islandExpanded && !menuOpen,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 76.dp),
                enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { -it / 3 },
                exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { -it / 3 }
            ) {
                Row(Modifier.background(Panel, RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF555555), RoundedCornerShape(16.dp)).padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("YORU", color = White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Text("С возвращением, Player", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.width(12.dp))
                    Text("Открыть меню  ↗", color = White, fontSize = 11.sp, modifier = Modifier.clickable { menuOpen = true; islandExpanded = false })
                }
            }

            AnimatedVisibility(
                visible = menuOpen,
                modifier = Modifier.fillMaxSize(),
                enter = fadeIn(tween(180)) + slideInVertically(tween(240, easing = FastOutSlowInEasing)) { it / 18 },
                exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { it / 18 }
            ) {
                MainMenu(
                    selected = selected,
                    categories = categories,
                    onSelect = { selected = it },
                    onClose = { menuOpen = false },
                    onPlayers = { showPlayerList = true }
                )
            }

            if (showPlayerList) {
                Dialog(onDismissRequest = { showPlayerList = false }) {
                    Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(18.dp)).padding(20.dp)) {
                        Text("PLAYERS", color = White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("Список игроков станет доступен после подключения Minecraft runtime.", color = Muted)
                        TextButton(onClick = { showPlayerList = false }) { Text("CLOSE", color = White) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Island(expanded: Boolean, onTap: () -> Unit, onDoubleTap: () -> Unit, modifier: Modifier = Modifier) {
    val width by animateDpAsState(if (expanded) 220.dp else 124.dp, tween(260, easing = FastOutSlowInEasing), label = "islandWidth")
    val height by animateDpAsState(if (expanded) 48.dp else 34.dp, tween(260, easing = FastOutSlowInEasing), label = "islandHeight")
    val shape = RoundedCornerShape(50)
    Row(
        modifier.width(width).height(height).background(Black, shape).border(1.dp, Color(0xFF555555), shape)
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }, onDoubleTap = { onDoubleTap() }) }
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text("个", color = White, fontSize = if (expanded) 20.sp else 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text("YORU", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        AnimatedVisibility(visible = expanded) {
            Text("  CLIENT", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun MainMenu(
    selected: String,
    categories: List<String>,
    onSelect: (String) -> Unit,
    onClose: () -> Unit,
    onPlayers: () -> Unit
) {
    Row(Modifier.fillMaxSize().background(Color(0x99000000)).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        // Left navigation, matching the supplied in-game reference but using YORU's white accent.
        Column(Modifier.width(174.dp).fillMaxHeight().background(Panel, RoundedCornerShape(18.dp)).border(1.dp, Color(0xFF444444), RoundedCornerShape(18.dp)).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).background(White, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Text("个", color = Black, fontWeight = FontWeight.Black, fontSize = 22.sp)
                }
                Spacer(Modifier.width(9.dp))
                Column {
                    Text("YORU", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("CLIENT", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
            }
            Spacer(Modifier.height(17.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.weight(1f)) {
                items(categories) { category ->
                    val active = selected == category
                    Row(Modifier.fillMaxWidth().background(if (active) White else Color.Transparent, RoundedCornerShape(10.dp))
                        .clickable { onSelect(category) }.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(categoryIcon(category), color = if (active) Black else Muted, fontSize = 16.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(category, color = if (active) Black else White, fontSize = 13.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
            Text("YORU CLIENT  •  0.1.1", color = Soft, fontSize = 9.sp)
        }

        Column(Modifier.weight(1f).fillMaxHeight().background(Panel, RoundedCornerShape(18.dp)).border(1.dp, Color(0xFF444444), RoundedCornerShape(18.dp)).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(selected.uppercase(), color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("YORU Client  /  Module Center", color = Muted, fontSize = 10.sp)
                }
                Text("×", color = White, fontSize = 25.sp, modifier = Modifier.clickable { onClose() }.padding(horizontal = 8.dp))
            }
            Spacer(Modifier.height(13.dp))
            when (selected) {
                "Info" -> InfoPanel()
                "Combat" -> ModuleList(listOf("KillAura", "AutoClicker", "Reach", "Criticals", "Velocity", "AimAssist"))
                "Movement" -> ModuleList(listOf("Speed", "Fly", "LongJump", "Step", "Sprint", "NoSlow"))
                "Render", "Visual" -> ModuleList(listOf("ESP", "Fullbright", "NameTags", "PlayerESP", "Tracers", "Chams", "MiniMap", "Target HUD"))
                "Player" -> ModuleList(listOf("身", "NoHurtCam", "AntiAFK", "Inventory View", "Player Info"))
                "World" -> ModuleList(listOf("Waypoints", "Coordinates", "World Info", "Cave Map", "Death Points"))
                "Utility" -> ModuleList(listOf("AutoTool", "Fast Place", "Item Info", "Import Manager"))
                "Misc" -> ModuleList(listOf("Notifications", "Debug Overlay", "Session Stats"))
                "Settings" -> ModuleList(listOf("AMOLED Theme", "White Accent", "HUD Editor", "Interface Scale", "Configs"))
                else -> ModuleList(listOf("Gyroscope", "Input Manager", "Plugin Manager", "Network Status"))
            }
        }

        Column(Modifier.width(132.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).border(1.dp, Color(0xFF444444), RoundedCornerShape(15.dp)).padding(12.dp)) {
                Text("STATUS", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(7.dp))
                Text("FPS  --", color = White, fontSize = 12.sp)
                Text("PING  --", color = Muted, fontSize = 11.sp)
                Text("TPS  --", color = Muted, fontSize = 11.sp)
            }
            Column(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).border(1.dp, Color(0xFF444444), RoundedCornerShape(15.dp)).padding(10.dp)) {
                Text("HUD", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                listOf("KillAura", "Criticals", "ESP", "Fullbright", "NameTags", "PlayerESP", "Tracers", "HUD").forEach {
                    Text(it, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            }
            Text("PLAYERS", color = White, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).clickable { onPlayers() }.padding(10.dp))
        }
    }
}

@Composable
private fun ModuleList(names: List<String>) {
    var enabled by remember { mutableStateOf(setOf("KillAura", "Criticals")) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(names) { name ->
            val active = enabled.contains(name)
            Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(11.dp)).animateContentSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(name, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Module interface preview", color = Soft, fontSize = 9.sp)
                }
                Switch(checked = active, onCheckedChange = { checked -> enabled = if (checked) enabled + name else enabled - name }, colors = SwitchDefaults.colors(checkedThumbColor = Black, checkedTrackColor = White, uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0xFF444444)))
            }
        }
    }
}

@Composable
private fun InfoPanel() {
    Column(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(13.dp)).padding(16.dp)) {
        Text("YORU CLIENT", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("AMOLED interface • white accent • in-game overlay", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp))
        Text("This is an interface prototype. Game data and module actions will be connected after the island and menu are finalized.", color = White, fontSize = 12.sp)
    }
}

private fun categoryIcon(category: String): String = when (category) {
    "Info" -> "ⓘ"
    "Combat" -> "⚔"
    "Movement" -> "⌁"
    "Render", "Visual" -> "◇"
    "Player" -> "♙"
    "World" -> "◎"
    "Utility" -> "⌘"
    "Misc" -> "▣"
    else -> "⚙"
}
