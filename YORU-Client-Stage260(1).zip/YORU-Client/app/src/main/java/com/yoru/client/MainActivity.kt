package com.yoru.client

import android.content.Intent
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.io.File

private val Black = Color(0xFF000000)
private val White = Color(0xFFFFFFFF)
private val Muted = Color(0xFF888888)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleImportIntent(intent)
        setContent { YoruApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleImportIntent(intent)
    }

    private fun handleImportIntent(intent: Intent?) {
        if (intent == null) return
        val uri = intent.data ?: intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        if (uri != null) {
            runCatching {
                val base = File(filesDir, "minecraft/imports").apply { mkdirs() }
                val name = (contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
                } ?: "incoming-pack-${System.currentTimeMillis()}.zip")
                    .replace(Regex("[^A-Za-z0-9._-]"), "_")
                contentResolver.openInputStream(uri)?.use { input ->
                    File(base, name).outputStream().use(input::copyTo)
                }
            }
        }
    }
}

@Composable
private fun YoruApp() {
    var selected by remember { mutableStateOf("Info") }
    var showPlayerList by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var activeModule by remember { mutableStateOf<String?>(null) }
    var glassTheme by remember { mutableStateOf(false) }
    val moduleStates = remember { mutableStateMapOf<String, Boolean>() }
    val categories = listOf("Info", "Combat", "Movement", "Render", "Build", "Gyroscope", "Player", "World", "Network", "Plugins", "Utility", "Misc", "Settings")
    val panel = if (glassTheme) Color(0xFF202020) else Color(0xFF111111)
    val card = if (glassTheme) Color(0xFF303030) else Color(0xFF191919)

    MaterialTheme(colorScheme = darkColorScheme(background = Black, surface = panel, primary = White)) {
        Row(Modifier.fillMaxSize().background(Black).padding(14.dp)) {
            Column(Modifier.width(154.dp).fillMaxHeight().background(panel, RoundedCornerShape(18.dp)).padding(12.dp)) {
                Text("个", color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("YORU CLIENT", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(18.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(categories) { item ->
                        val active = selected == item
                        Text(
                            item,
                            color = if (active) Black else White,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth()
                                .background(if (active) White else Color.Transparent, RoundedCornerShape(9.dp))
                                .clickable { selected = item }
                                .padding(horizontal = 11.dp, vertical = 10.dp)
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("YORU • 0.1.0", color = Muted, fontSize = 10.sp)
            }

            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).fillMaxHeight().background(panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(selected.uppercase(), color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("In-game interface prototype", color = Muted, fontSize = 11.sp)
                    }
                    Text("FPS -- • Runtime not connected", color = Muted, fontSize = 10.sp)
                }
                Spacer(Modifier.height(18.dp))
                when (selected) {
                    "Info" -> InfoContent(card)
                    "Combat" -> FeatureList(listOf("TriggerBot", "AimBot", "Target Assist", "Target HUD", "Hitbox", "Combat Stats"), card) { activeModule = it }
                    "Movement" -> FeatureList(listOf("Sprint", "Step", "No Slow", "Movement HUD"), card) { activeModule = it }
                    "Render" -> FeatureList(listOf("Chams", "Square MiniMap", "Biome Overlay", "Player Dots", "Waypoints", "Death Points", "Compass", "Entity Radar", "4:3", "Footsteps"), card) { activeModule = it }
                    "Build" -> FeatureList(listOf("Build Assist", "Block Outline", "Placement Preview"), card) { activeModule = it }
                    "Gyroscope" -> FeatureList(listOf("Sensitivity X", "Sensitivity Y", "Smoothing", "Deadzone", "Invert X", "Invert Y", "Calibration"), card) { activeModule = it }
                    "Player" -> FeatureList(listOf("Player HUD", "Coordinates", "Effects Display"), card) { activeModule = it }
                    "World" -> FeatureList(listOf("World Info", "Time Display", "Weather Display"), card) { activeModule = it }
                    "Network" -> FeatureList(listOf("Connection Info", "Ping Display", "Diagnostics"), card) { activeModule = it }
                    "Plugins" -> FeatureList(listOf("Plugin Repository", "Installed Plugins", "Publisher Info"), card) { activeModule = it }
                    "Utility" -> FeatureList(listOf("Clock", "Notifications", "Quick Actions"), card) { activeModule = it }
                    "Misc" -> FeatureList(listOf("Interface Settings", "HUD Visibility", "About YORU"), card) { activeModule = it }
                    "Settings" -> {
                        FeatureCard("AMOLED Theme", "Чёрный фон и тёмные поверхности", card, onClick = { glassTheme = false })
                        Spacer(Modifier.height(8.dp))
                        FeatureCard("Glass Theme", "Графитовые поверхности", card, onClick = { glassTheme = true })
                        Spacer(Modifier.height(8.dp))
                        FeatureList(listOf("HUD Editor", "Import worlds & packs", "Storage manager"), card) { activeModule = it }
                    }
                }
            }

            Spacer(Modifier.width(12.dp))
            Column(Modifier.width(152.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f)
                        .background(Color(0xFF151515), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp))
                        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { showPlayerList = true }) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("MINIMAP\n\n  •     •\n\n    ▲\n\nSQUARE", color = White, fontSize = 12.sp, lineHeight = 19.sp)
                }
                Text("DOUBLE TAP: PLAYERS", color = Muted, fontSize = 9.sp)
                FeatureCard("个", "Island • compact", card, onClick = { expanded = !expanded })
                Button(onClick = { expanded = !expanded }, colors = ButtonDefaults.buttonColors(containerColor = White, contentColor = Black), modifier = Modifier.fillMaxWidth()) {
                    Text(if (expanded) "Collapse" else "Expand")
                }
                if (expanded) Text("С возвращением, Player", color = White, fontSize = 11.sp)
            }
        }

        if (showPlayerList) {
            Dialog(onDismissRequest = { showPlayerList = false }) {
                Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(16.dp)).padding(18.dp)) {
                    Text("PLAYERS", color = White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Игровой список появится после подключения Bedrock runtime.", color = Muted)
                    TextButton(onClick = { showPlayerList = false }) { Text("CLOSE", color = White) }
                }
            }
        }

        activeModule?.let { module ->
            ModuleDialog(
                title = module,
                enabled = moduleStates[module] ?: false,
                onEnabledChange = { moduleStates[module] = it },
                onDismiss = { activeModule = null },
                panel = panel
            )
        }
    }
}

@Composable
private fun InfoContent(card: Color) {
    val uriHandler = LocalUriHandler.current
    Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(12.dp)).padding(16.dp)) {
        Text("YORU Client", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        Text("данный софт является бесплатным, если ты его купил то ты ебень", color = White, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text("тгк с апдейтами, гайдами и прочим:", color = White, fontSize = 13.sp)
        Text(
            "https://t.me/yoruclient",
            color = White,
            fontSize = 13.sp,
            modifier = Modifier.clickable { runCatching { uriHandler.openUri("https://t.me/yoruclient") } }
        )
        Spacer(Modifier.height(12.dp))
        Text(", в будущем будет поддержка:", color = White, fontSize = 13.sp)
        Text("юз бота", color = White, fontSize = 13.sp)
    }
}

@Composable
private fun FeatureList(items: List<String>, card: Color, onItemClick: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { item ->
            FeatureCard(item, "Открыть настройки • прототип интерфейса", card, onClick = { onItemClick(item) })
        }
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, card: Color, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(card, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(14.dp)
    ) {
        Text(title, color = White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ModuleDialog(
    title: String,
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    panel: Color
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(16.dp)).padding(18.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Включить", color = White)
                    Text("Переключатель интерфейса", color = Muted, fontSize = 11.sp)
                }
                Switch(checked = enabled, onCheckedChange = onEnabledChange)
            }
            Spacer(Modifier.height(10.dp))
            Text("Это состояние пока сохраняется только в интерфейсе. Подключение к Minecraft runtime ещё не реализовано.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                Text("CLOSE", color = White)
            }
        }
    }
}
