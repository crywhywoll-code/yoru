# YORU Client — Android prototype

This repository contains the YORU Client Android application shell, in-game menu prototype, UI/architecture specifications, and Android import/storage design.

**Important:** this is not yet a working Minecraft Bedrock client injection/modification layer. The current app is a buildable Android prototype. Minecraft runtime integration, Bedrock APIs/version compatibility, live entity data, rendering hooks, and world/pack import validation must be implemented and tested separately.

## Build
- Android Studio / Gradle
- JDK 17
- Android SDK 35
- Run `./gradlew assembleDebug`

GitHub Actions builds a Debug APK on push to `main`.

## Product decisions captured
- Name: YORU Client; symbol: 个
- AMOLED theme: `#000000`; Glass theme: dark graphite
- Main accent: `#FFFFFF`
- Landscape in-game menu concept; Dynamic Island compact/expanded behavior
- Square MiniMap (resizable/repositionable), player dots, biome overlay, waypoints, compass, entity markers, player list on double tap
- Combat and Render feature catalog in `docs/FEATURES.md`
- Worlds and resource/behavior packs stored in app-private storage, not public Gallery
- `.mcworld`, `.mcpack`, `.mcaddon` imports accepted through Android share/open intents, subject to Android chooser and source-app support

## Storage privacy
YORU stores imported content under `context.filesDir/minecraft/`:
- `worlds/`
- `resource_packs/`
- `behavior_packs/`
- `skin_packs/`
- `imports/`

These folders are private to the app and do not appear in Gallery. No broad media/storage permission is requested. Files are received through `content://` URIs and copied into app-private storage. Export/share uses Android's Storage Access Framework or FileProvider-style content URIs.


## Halcyon / Minecraft integration research

A static inspection of the supplied Halcyon 25.3.1 and Minecraft PE 1.1.5.1 APKs is documented in `docs/HALCYON_RESEARCH.md`. The `native/` and Android bridge files are YORU-owned interface scaffolding only; they are not a working injection or game integration. The supplied third-party APK binaries are intentionally not bundled.
