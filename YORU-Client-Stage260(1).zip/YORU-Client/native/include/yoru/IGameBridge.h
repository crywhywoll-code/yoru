#pragma once

#include <cstdint>
#include <optional>
#include <string>

namespace yoru::game {

struct Vec3 {
    float x{};
    float y{};
    float z{};
};

struct Rotation {
    float yaw{};
    float pitch{};
};

struct PlayerSnapshot {
    std::string name;
    Vec3 position;
    Rotation rotation;
    float health{};
    bool onGround{};
};

enum class RuntimeState {
    Unavailable,
    Loading,
    InGame,
    Leaving
};

// Stable YORU-owned contract. A version-specific adapter must implement this
// only after its calls, signatures, thread rules, and object lifetimes are
// independently verified against the exact game build.
class IGameBridge {
public:
    virtual ~IGameBridge() = default;

    virtual RuntimeState state() const = 0;
    virtual std::optional<PlayerSnapshot> localPlayer() const = 0;
    virtual std::optional<float> framesPerSecond() const = 0;
};

} // namespace yoru::game
