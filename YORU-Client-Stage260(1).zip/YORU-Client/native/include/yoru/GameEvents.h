#pragma once

#include "IGameBridge.h"

namespace yoru::game {

struct TickEvent {
    std::uint64_t tick{};
};

struct RenderEvent {
    float partialTick{};
};

struct PlayerLoadedEvent {
    bool localPlayerAvailable{};
};

// Event names are YORU-owned contracts. A real dispatcher and runtime source
// still need to be implemented and validated for Minecraft PE 1.1.5.1.

} // namespace yoru::game
