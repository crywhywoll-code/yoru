#include "yoru/IGameBridge.h"

namespace yoru::game {

// Deliberately no Minecraft calls here. This translation unit documents the
// native boundary without pretending that an unverified game adapter exists.

} // namespace yoru::game
